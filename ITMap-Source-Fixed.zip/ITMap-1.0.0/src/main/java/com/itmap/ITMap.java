package com.itmap;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ITMap implements ClientModInitializer {
    private static KeyBinding openMapKey;

    @Override
    public void onInitializeClient() {
        openMapKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.itmap.open_map",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_M,
                KeyBinding.Category.MISC
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMapKey.wasPressed()) {
                client.setScreen(new ITMapScreen());
            }
        });
    }

    static Path seedFile() {
        return MinecraftClient.getInstance().runDirectory.toPath()
                .resolve("config").resolve("itmap-seed.txt");
    }

    static String loadSeed() {
        Path path = seedFile();
        try {
            return Files.exists(path) ? Files.readString(path, StandardCharsets.UTF_8).trim() : "";
        } catch (IOException e) {
            return "";
        }
    }

    static boolean saveSeed(String seed) {
        Path path = seedFile();
        try {
            Files.createDirectories(path.getParent());
            Files.writeString(path, seed.trim(), StandardCharsets.UTF_8);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    private static final class ITMapScreen extends Screen {
        private TextFieldWidget seedField;
        private String status = "Enter a world seed and press Save.";

        protected ITMapScreen() {
            super(Text.literal("IT Map"));
        }

        @Override
        protected void init() {
            int centerX = width / 2;
            seedField = new TextFieldWidget(textRenderer, centerX - 120, height / 2 - 35,
                    240, 20, Text.literal("World seed"));
            seedField.setMaxLength(64);
            seedField.setPlaceholder(Text.literal("Enter seed (number or text)"));
            seedField.setText(loadSeed());
            addDrawableChild(seedField);

            addDrawableChild(ButtonWidget.builder(Text.literal("Save Seed"), button -> {
                String seed = seedField.getText().trim();
                if (seed.isEmpty()) {
                    status = "Seed cannot be empty.";
                } else if (saveSeed(seed)) {
                    status = "Seed saved: " + seed;
                } else {
                    status = "Could not save seed. Check file permissions.";
                }
            }).dimensions(centerX - 120, height / 2 - 5, 115, 20).build());

            addDrawableChild(ButtonWidget.builder(Text.literal("Load Saved"), button -> {
                seedField.setText(loadSeed());
                status = "Saved seed loaded.";
            }).dimensions(centerX + 5, height / 2 - 5, 115, 20).build());

            addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> close())
                    .dimensions(centerX - 40, height / 2 + 28, 80, 20).build());
            setInitialFocus(seedField);
        }

        @Override
        public void render(net.minecraft.client.gui.DrawContext context, int mouseX, int mouseY, float delta) {
            renderBackground(context, mouseX, mouseY, delta);
            context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 75, 0xFFFFFF);
            context.drawCenteredTextWithShadow(textRenderer, Text.literal(status),
                    width / 2, height / 2 + 58, 0xB8D8FF);
            context.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("Saved locally in config/itmap-seed.txt"),
                    width / 2, height / 2 + 72, 0xAAAAAA);
            super.render(context, mouseX, mouseY, delta);
        }

        @Override
        public boolean shouldPause() {
            return false;
        }
    }
}
